document.addEventListener('DOMContentLoaded', function () {
    updateCartDisplay();
});

function updateCartDisplay() {
    const cartContainer = document.querySelector('.cart-container tbody');
    cartContainer.innerHTML = '';

    let cart = JSON.parse(localStorage.getItem('cart')) || {};
    let total = 0;

    for (let item in cart) {
        let row = document.createElement('tr');
        row.id = item;

        let itemImage = document.createElement('td');
        let imgElement = document.createElement('img');
        imgElement.src = cart[item].imageUrl;
        imgElement.alt = item;
        imgElement.style.width = '50px'; // Ajuste o tamanho da imagem conforme necessário
        itemImage.appendChild(imgElement);

        let itemName = document.createElement('td');
        itemName.textContent = item;

        let itemQuantity = document.createElement('td');
        itemQuantity.innerHTML = `
            <button onclick="updateQuantity('${item}', -1)">-</button>
            <input type="text" id="quantity-${item}" value="${cart[item].quantity}" readonly>
            <button onclick="updateQuantity('${item}', 1)">+</button>
        `;

        let itemPrice = document.createElement('td');
        itemPrice.textContent = `R$${(cart[item].price * cart[item].quantity).toFixed(2)}`;

        row.appendChild(itemImage);
        row.appendChild(itemName);
        row.appendChild(itemQuantity);
        row.appendChild(itemPrice);

        cartContainer.appendChild(row);

        total += cart[item].price * cart[item].quantity;
    }

    document.getElementById('total').innerText = `R$${total.toFixed(2)}`;
    document.getElementById('subtotal').innerText = `R$${total.toFixed(2)}`;
}

function updateQuantity(item, change) {
    let cart = JSON.parse(localStorage.getItem('cart'));
    cart[item].quantity += change;

    if (cart[item].quantity < 1) {
        delete cart[item];
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
}

function applyDiscount() {
    const discountInput = document.querySelector('.promo-code input');
    let discount = parseFloat(discountInput.value);
    if (isNaN(discount) || discount < 0) discount = 0;
    localStorage.setItem('discount', discount);
    updateTotal();
}

function updateTotal() {
    let cart = JSON.parse(localStorage.getItem('cart')) || {};
    let total = 0;

    for (let item in cart) {
        total += cart[item].price * cart[item].quantity;
    }

    const discount = parseFloat(localStorage.getItem('discount')) || 0;
    document.getElementById('discount').innerText = `-R$${discount.toFixed(2)}`;
    const subtotal = total - discount;
    document.getElementById('total').innerText = `R$${subtotal.toFixed(2)}`;
    document.getElementById('subtotal').innerText = `R$${subtotal.toFixed(2)}`;
}
