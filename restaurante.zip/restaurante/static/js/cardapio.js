function addToCart(item, price, imageUrl) {
    let cart = JSON.parse(localStorage.getItem('cart')) || {};

    if (cart[item]) {
        cart[item].quantity += 1;
    } else {
        cart[item] = {
            price: price,
            quantity: 1,
            imageUrl: imageUrl
        };
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${item} adicionado ao carrinho`);
}
